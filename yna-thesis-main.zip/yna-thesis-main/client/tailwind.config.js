/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: 'var(--color-primary)',
        secondary: 'var(--color-secondary)', //vFF6BAA
        accent: 'var(--color-accent)',
        red: '#EF5861',
      },
      backgroundColor: {
        primary: 'var(--color-primary)',
        primaryLight: 'var(--color-primary-light)',
        secondary: 'var(--color-secondary)',
        secondaryLight: 'var(--color-secondary-light)',
        tertiary: 'var(--color-tertiary)',
        cancel: '#EC5647',
        accent: 'var(--color-accent)',
        main: 'var(--color-main)',
        dark: '#231f20',
        red: '#EF5861',
        yellow: '#FFDB5C',
      },
      fontSize: {
        sm: '0.875rem',
        base: '1rem',
        lg: '1.125rem',
      },
      boxShadow: {
        bottom: '0px 4px 6px -1px rgba(0, 0, 0, 0.1), 0px 2px 4px -1px rgba(0, 0, 0, 0.06)',
        primary: 'var(--color-primary)',
      },
      border: {
        primary: 'var(--color-primary)',
      },
    },
  },
  plugins: [],
};

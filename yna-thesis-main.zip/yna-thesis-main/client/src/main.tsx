import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import { BrowserRouter } from 'react-router-dom';
import { AuthContextProvider } from './layout/auth/stores/AuthContext';
import { ModalProvider } from './components/modal/modalContext';
createRoot(document.getElementById('root')!).render(
  <BrowserRouter>
    <ModalProvider>
      <AuthContextProvider>
        <App />
      </AuthContextProvider>
    </ModalProvider>
  </BrowserRouter>
);

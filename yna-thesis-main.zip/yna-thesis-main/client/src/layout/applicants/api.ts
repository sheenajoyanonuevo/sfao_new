/* eslint-disable @typescript-eslint/no-explicit-any */
import axios, { InternalAxiosRequestConfig } from 'axios';
import { API_ENDPOINT } from '../../config/API';

const USER_API = axios.create({ baseURL: API_ENDPOINT });

USER_API.interceptors.request.use((req: InternalAxiosRequestConfig<any>) => {
  const storage = sessionStorage.getItem('token');
  if (storage !== null && storage) {
    req.headers.Authorization = `Bearer ${storage}`;
  }
  return req;
});

export const registerApplicant = async (data: any) => {
  try {
    const response = await USER_API.post(`${API_ENDPOINT}/api/applicant/create`, data);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      return {
        success: false,
        status: error.response?.status,
        message: error.message,
        data: error.response?.data,
      };
    } else {
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }
};

export const getAllApplicant = async (id: string) => {
  try {
    const response = await USER_API.get(`/api/applicant/${id}`);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      return {
        success: false,
        status: error.response?.status,
        message: error.message,
        data: error.response?.data,
      };
    } else {
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }
};

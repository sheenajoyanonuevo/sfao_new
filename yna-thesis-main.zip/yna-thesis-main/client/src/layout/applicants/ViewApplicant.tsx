/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import Input from '../../components/Input';
import { MdEditNote } from 'react-icons/md';
import Button from '../../components/Button';
import { useModal } from '../../components/modal/modalContext';
import { v4 as uuidv4 } from 'uuid';
import toast, { Toaster } from 'react-hot-toast';
import { useAuth } from '../auth/stores/AuthContext';
import Dropdown from '../../components/Dropdown';
import { BsPeopleFill } from 'react-icons/bs';
import { FaGraduationCap } from 'react-icons/fa';
import { IoCloseOutline, IoHeartCircle } from 'react-icons/io5';
import { academicForm, familyForm, forms } from '../users/forms';
import Container from '../../components/Container';
import { BiCheck } from 'react-icons/bi';
import { statusColors } from '../../helpers/statusColor';
import TextArea from '../../components/TextArea';
import { formsApplicant } from './formApplicant';
import LastLoader from './LastLoader';
import { registerApplicant } from './api';

const ViewApplicant = ({ rowId = '' }: { rowId?: string }) => {
  const { closeModal } = useModal();
  const { dispatch, allUser, applicants } = useAuth();

  const [data, setData] = React.useState<any>({ _id: uuidv4() });

  const [formData, setFormData] = useState<any>({
    _id: uuidv4(),
    firstName: '',
    lastName: '',
    birthday: new Date().toISOString(),
    userName: '',
    email: '',
    cluster: '',
    barangay: '',
    profile: '',
    school: '',
    statusUpdate: [],
    remarks: '',
  });

  console.log(formData);
  const [activeMenu, setActiveMenu] = useState(0);
  const loadingMenu = [<BsPeopleFill />, <FaGraduationCap />, <IoHeartCircle />, <MdEditNote />, <BiCheck />];

  const handleNext = () => {
    if (activeMenu < 4) {
      setActiveMenu((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (activeMenu > 0) {
      setActiveMenu((prev) => prev - 1);
    }
  };

  useEffect(() => {
    if (rowId) {
      const item = applicants.find((x: any) => x._id === rowId);
      if (item) {
        setFormData({
          ...item,
          _id: item._id,
          statusUpdate: item.statusUpdate.reverse(),
        });
      }
    }
  }, [rowId]);

  useEffect(() => {
    if (rowId) {
      const item = allUser.find((x: any) => x._id === formData.applicantId);
      console.log(item);
      if (item?.personalData && item) {
        const { firstName, lastName, middleName, birthday, birthplace, age } = item.personalData;
        const { streetAddres, city, state, zipcode } = item.personalData.address;
        const {
          fatherName,
          fatherAlive,
          fatherAddress,
          fatherOccupation,
          motherName,
          motherAlive,
          motherAddress,
          motherOccupation,
          totalGross,
          numberSibling,
        } = item.familyData;
        const {
          srCode,
          isGraduated,
          program,
          college,
          yearLevel,
          campus,
          gwa,
          honors,
          unitEnrolled,
          scholarshipApplied,
          semester,
          academicYear,
          hasExistingScholar,
          hasExistingScholarName,
        } = item.academicData;
        const formData = {
          _id: item._id,
          firstName,
          lastName,
          middleName,
          birthday,
          birthplace,
          streetAddres,
          city,
          state,
          zipcode,
          age,
          email: item.email,
          userName: item.userId,
          // Academic Data
          srCode,
          isGraduated,
          program,
          college,
          yearLevel,
          campus,
          gwa,
          honors,
          unitEnrolled,
          scholarshipApplied,
          semester,
          academicYear,
          hasExistingScholar,
          hasExistingScholarName,

          // Family Information
          fatherName,
          fatherAlive,
          fatherAddress,
          fatherOccupation,
          motherName,
          motherAlive,
          motherAddress,
          motherOccupation,
          totalGross,
          numberSibling,
          password: item.password,
        };

        setData(formData);
      }
    }
  }, [allUser, formData.applicantId, rowId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;

    setFormData((prev: any) => ({
      ...prev,
      [name]: type === 'number' ? Number(value) : value,
    }));
  };

  const handleSubmit = async () => {
    if (formData.status === 'approved') {
      closeModal();
      return;
    }
    const data = {
      ...formData,
      statusUpdate: [
        ...formData.statusUpdate.reverse(),
        {
          status: formData.status,
          date: new Date().toISOString(),
          reason: formData.remarks,
        },
      ],
    };
    if (window.confirm('Update this Application?')) {
      setActiveMenu(5);
    }

    const res = await registerApplicant(data);
    if (res.success === false) return toast.error(res.data?.msg || 'Error');
    dispatch({ type: 'ADD_APPLICANT', payload: res });
    toast.success(res.msg);

    // setTimeout(() => {
    //   closeModal();
    // }, 1500);
  };

  const options = [
    {
      value: 'pending',
      label: 'Pending',
    },

    {
      value: 'approved',
      label: 'Approve',
    },

    {
      value: 'cancelled',
      label: 'Cancel',
    },

    {
      value: 'rejected',
      label: 'Reject',
    },
  ];

  return (
    <Container id=''>
      <section className='w-full flex items-center justify-center h-screen'>
        <Toaster />
        <div className='relative w-2/3 p-4 shadow-md bg-white'>
          <div
            className='absolute right-3 top-3 text-red z-30'
            onClick={closeModal}
            id='close-modal'
          >
            <IoCloseOutline />
          </div>
          <div className='relative overflow-x-hidden '>
            <div
              className='flex transition-transform duration-500 ease-in-out '
              style={{
                transform: `translateX(-${activeMenu * 100}%)`,
                width: '100%',
              }}
            >
              {/* Personal Information */}
              <div className='w-full flex-none'>
                {activeMenu === 0 && (
                  <div className='w-full flex flex-wrap gap-3 content-start items-start'>
                    <h1 className='font-semibold w-full mb-3'>Personal Information</h1>
                    {forms.map((frm, index) => (
                      <Input
                        label={frm.label}
                        key={index}
                        readOnly
                        pattern='[0-9]*'
                        name={frm.title}
                        type={frm.type}
                        containerClassName='lg:w-[49%]'
                        required={frm.rquired}
                        checked={data && data[frm.title]}
                        value={(data && data[frm.title]) || ''}
                        onChange={handleChange}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Academic Data */}
              <div className='w-full flex-none  overflow-y-auto max-h-[80vh]'>
                {activeMenu === 1 && (
                  <div className='w-full flex flex-wrap gap-3'>
                    <h1 className='font-semibold w-full mb-3'>Academic Data</h1>
                    {academicForm.map((frm, index) => {
                      if (frm.type === 'select') {
                        return (
                          <div className='lg:w-[49%]'>
                            <Dropdown
                              onChange={(x) => setData({ ...data, [frm.title]: x.target.value })}
                              options={
                                (frm.options &&
                                  frm.options.map((x) => {
                                    return {
                                      value: x,
                                      label: x.toUpperCase(),
                                    };
                                  })) ||
                                []
                              }
                              value={data?.[frm.title]}
                              label={frm.label}
                            />
                          </div>
                        );
                      }
                      return (
                        <Input
                          label={frm.label}
                          key={index}
                          pattern='[0-9]*'
                          checked={data && data[frm.title]}
                          name={frm.title}
                          type={frm.type}
                          readOnly
                          containerClassName='lg:w-[49%]'
                          checkboxLabel={frm.checkboxLabel}
                          value={(data && data[frm.title]) || ''}
                          onChange={handleChange}
                        />
                      );
                    })}
                  </div>
                )}
              </div>

              {/* family */}
              <div className='w-full flex-none '>
                {activeMenu === 2 && (
                  <div className='w-full flex flex-wrap gap-3'>
                    <h1 className='font-semibold w-full mb-3'>Family Information</h1>
                    {familyForm.map((frm, index) => (
                      <Input
                        label={frm.label}
                        readOnly
                        key={index}
                        pattern='[0-9]*'
                        checkboxLabel={frm.checkboxLabel}
                        name={frm.title}
                        type={frm.type}
                        containerClassName='lg:w-[49%]'
                        value={(data && data[frm.title]) || ''}
                        onChange={handleChange}
                        checked={data && data[frm.title]}
                      />
                    ))}
                  </div>
                )}
              </div>
              {/* requirements */}
              <div className='w-full flex-none '>
                {activeMenu === 3 && (
                  <div className='w-full flex flex-wrap gap-3'>
                    <h1 className='font-semibold w-full mb-3'>Requirements Submitted</h1>
                    {formsApplicant.slice(6, 11).map((frm, index) => {
                      return (
                        <>
                          <Input
                            label={frm.label}
                            key={index}
                            pattern='[0-9]*'
                            name={frm.title}
                            type={frm.type}
                            customClassName={index === 0 ? 'border-none ' : ''}
                            containerClassName={index === 0 ? 'border-none !absolute right-0 !w-60' : ''}
                            readOnly={frm.readonly}
                            // value={formData[frm.title as keyof ProjectTypes] as any}
                            onChange={handleChange}
                          />
                        </>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* update the status */}
              <div className='w-full flex-none'>
                {activeMenu === 4 && (
                  <div className='w-full flex flex-wrap gap-3 pl-2'>
                    <h1 className='font-semibold w-full mb-3'>Requirements Submitted</h1>
                    <div className='w-full ml-1'>
                      <Dropdown
                        label='Update Application'
                        value={formData.status}
                        options={options}
                        id='status-dropdown'
                        containerClassName='mb-4'
                        onChange={(e) => {
                          setFormData({ ...formData, status: e.target.value });
                        }}
                      />
                    </div>
                    <TextArea
                      label={`${formData.status === 'rejected' ? 'Reason of Rejection' : 'Remarks'}`}
                      value={formData.remarks}
                      name='remarks'
                      onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                    />
                    <h1 className='font-semibold w-full mb-3'>Application History</h1>
                    <div className='relative m-0'>
                      <ul className='space-y-8'>
                        {formData.statusUpdate.map((update: any, index: number) => {
                          const isApprove = update.approvedBy && allUser.find((x) => x._id === update.approvedBy);

                          const name =
                            isApprove?.personalData?.firstName ||
                            isApprove?.firstName + ' ' + isApprove?.personalData?.lastName ||
                            isApprove?.lastName;
                          return (
                            <li
                              key={index}
                              className='flex items-start relative'
                            >
                              <div
                                className={`w-4 h-4 rounded-full z-20  ${
                                  statusColors[update.status]
                                } absolute left-0 mt-1.5`}
                              ></div>
                              <div className='ml-10'>
                                <p className='font-semibold capitalize text-lg '>{update.status}</p>
                                <p className='text-sm text-gray-500'>{new Date(update.date).toLocaleDateString()}</p>
                                {update.reason && <p className='text-sm text-gray-700 mt-1'>{update.reason}</p>}
                                <h2>{update.approvedBy && name}</h2>
                              </div>

                              {index < formData.statusUpdate.length - 1 && (
                                <div
                                  className={`absolute left-2 top-4 w-0.5 h-24 ${
                                    statusColors[update.status]
                                  } bg-gray-300`}
                                />
                              )}
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>
                )}
              </div>

              <div className='w-full flex-none '>
                {activeMenu === 5 && (
                  <div className='w-full flex flex-wrap gap-3'>
                    <LastLoader status={formData.status} />
                  </div>
                )}
              </div>

              {/* <div className='w-full flex-none'> {activeMenu === 6 && <LastLoader status={formData.status} />}</div> */}
            </div>
            {activeMenu !== 5 && (
              <div className='relative flex flex-col items-center mt-5 w-full'>
                {/* Icons */}
                <div className='relative flex items-center justify-between w-full z-10'>
                  {loadingMenu.map((Icon, index) => (
                    <div
                      key={index}
                      className={`p-2 rounded-full cursor-pointer flex items-center justify-center m-0 ${
                        index < activeMenu
                          ? 'bg-primary text-white'
                          : index === activeMenu
                          ? 'bg-primary text-white'
                          : 'bg-gray-100 text-gray-500'
                      }`}
                      onClick={() => setActiveMenu(index)}
                    >
                      {Icon}
                    </div>
                  ))}
                </div>

                {/* Progress Bar */}
                <div className='absolute top-1/2 transform -translate-y-1/2 w-full flex items-center'>
                  {loadingMenu.map((_, index) => (
                    <React.Fragment key={index}>
                      {index < loadingMenu.length - 1 && (
                        <div
                          className={`flex-1 h-2 ${
                            index < activeMenu ? 'bg-primary' : 'bg-gray-300'
                          } transition-colors duration-300 ease-in-out`}
                          style={{ marginLeft: '4px', marginRight: '4px' }}
                        />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            )}

            {activeMenu !== 5 && (
              <footer className='w-full mt-5 flex items-center justify-between'>
                {activeMenu > 0 && (
                  <Button
                    text='Previous'
                    customClassName='!px-3 !pr-4 bg-secondary'
                    onClick={handlePrevious}
                  />
                )}
                {activeMenu < 4 && (
                  <Button
                    text='Next'
                    onClick={handleNext}
                    customClassName='!px-3 !pr-4 bg-secondary'
                  />
                )}

                {activeMenu > 3 && (
                  <Button
                    text={formData.status === 'approved' ? 'Close' : 'Save'}
                    onClick={handleSubmit as any}
                    customClassName='!px-3 !pr-4 '
                  />
                )}
              </footer>
            )}
          </div>
        </div>
      </section>
    </Container>
  );
};

export default ViewApplicant;

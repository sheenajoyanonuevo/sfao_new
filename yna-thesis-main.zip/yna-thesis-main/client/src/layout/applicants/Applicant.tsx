/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import Container from '../../components/Container';
import { useAuth } from '../auth/stores/AuthContext';
import { useModal } from '../../components/modal/modalContext';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { BsPeopleFill } from 'react-icons/bs';
import Table from '../../components/Table';
import { UserTypes } from '../../helpers/types';
import ViewApplicant from './ViewApplicant';

const Applicant = ({ isRecord }: { isRecord?: boolean }) => {
  const headers = [
    {
      header: 'ID',
      accessor: 'userId',
    },
    {
      header: 'Name',
      accessor: 'applicantId',
    },
    {
      header: 'Status',
      accessor: 'status',
    },

    {
      header: 'Requirement Submitted',
      accessor: 'requirements',
    },
  ];

  const { applicants, allUser } = useAuth();
  const { isOpen } = useModal();
  const [val, setVal] = useState('');
  const [rowId, setRowId] = useState('');
  const [userData, setUserData] = useState<UserTypes[]>([]);

  useEffect(() => {
    if (rowId !== '') {
      document.getElementById('view-applicant')?.click();
    }
  }, [rowId]);

  useEffect(() => {
    if (!isOpen) {
      setRowId('');
    }
  }, [isOpen]);

  useEffect(() => {
    const filteredUsers = allUser.filter((user) => user?.userId?.includes(val));
    setUserData(filteredUsers);
  }, [val, allUser]);

  return (
    <Container id='applicant'>
      <div className='p-5'>
        <header className='flex justify-between w-full'>
          <span className='inline-flex m-0 items-center'>
            <h1 className='font-semibold'>All {isRecord ? 'Record' : 'Applicants'}</h1>
            <Input
              containerClassName='w-44 ml-4 m-0 !border-none'
              placeholder='Search ID '
              value={val}
              onChange={(e) => setVal(e.target.value)}
            />
          </span>
          {!isRecord && (
            <Button
              text=' New Application'
              ic={<BsPeopleFill />}
              customClassName='rounded-none bg-secondary'
              isModal={<ViewApplicant rowId={rowId} />}
              type='button'
              id='view-applicant'
            />
          )}
        </header>
        {isRecord && (
          <Button
            text=' New Application'
            ic={<BsPeopleFill />}
            customClassName='rounded-none bg-secondary hidden'
            isModal={<ViewApplicant rowId={rowId} />}
            type='button'
            id='view-applicant'
          />
        )}
        <Table
          title='applicant'
          data={applicants
            ?.filter((x) => (isRecord ? x.status === 'approved' : x.status !== 'approved'))
            .filter((applicant) => {
              const user = userData.find((user) => user._id === applicant.applicantId);

              if (user) {
                return user.role === 'user';
              }

              return false;
            })
            .map((x) => {
              const isName = userData.find((y) => y._id === x.applicantId);
              const name = isName?.personalData?.firstName + ' ' + isName?.personalData?.lastName;
              const fields = {
                schoolId: x.schoolId,
                enrollmentForm: x.enrollmentForm,
                recentGrades: x.recentGrades,
                psa: x.psa,
              };

              const nonEmptyFieldsCount = Object.values(fields).filter((value) => value !== '').length;
              const totalFieldsCount = Object.keys(fields).length;
              const progress = `${nonEmptyFieldsCount}/${totalFieldsCount}`;
              return {
                ...x,
                applicantId: name,
                requirements: progress,
                userId: isName?.userId,
              };
            })}
          columns={headers as any}
          onEdit={(data: any) => setRowId(data._id)}
          onRemove={function (): void {
            throw new Error('Function not implemented.');
          }}
          isRecord={isRecord}
        />
      </div>
    </Container>
  );
};

export default Applicant;

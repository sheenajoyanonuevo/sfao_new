import React from 'react';
import Button from '../../components/Button';
import { useModal } from '../../components/modal/modalContext';

const LastLoader = ({ status }: { status: string }) => {
  const { closeModal } = useModal();
  return (
    <div className='flex items-center flex-col justify-between  gap-4'>
      <h1>Application Updated</h1>
      <h2 className='uppercase font-semibold'> {status}</h2>
      <Button
        text='OK'
        customClassName='!pr-6'
        onClick={closeModal}
      />
    </div>
  );
};

export default LastLoader;

export const formsApplicant = [
  {
    label: 'Applicant ID',
    title: '_id',
    type: 'text',
    readonly: true,
  },
  {
    label: 'First Name',
    title: 'firstName',
    type: 'text',
  },
  {
    label: 'Last Name',
    title: 'lastName',
    type: 'text',
  },
  {
    label: 'Email',
    title: 'email',
    type: 'email',
    readonly: true,
  },
  { label: 'Birthday', title: 'birthday', type: 'date' },
  {
    label: 'School',
    title: 'school',
    type: 'text',
  },

  {
    label: 'School ID',
    title: 'schoolId',
    type: 'file',
    required: true,
  },

  {
    label: 'Enrollment Form',
    title: 'enrollmentForm',
    type: 'file',
    required: true,
  },

  {
    label: 'Recent Grades',
    title: 'recentGrades',
    type: 'file',
    required: true,
  },

  {
    label: 'PSA/NSO',
    title: 'psa',
    type: 'file',
    required: true,
  },

  {
    label: 'Voter Registration',
    title: 'votersReigstration',
    type: 'file',
  },
];

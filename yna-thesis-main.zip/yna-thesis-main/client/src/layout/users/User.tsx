/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import Container from '../../components/Container';
import Button from '../../components/Button';
import { BsPeopleFill } from 'react-icons/bs';
import NewUser from './NewUser';
import { useAuth } from '../auth/stores/AuthContext';
import Table from '../../components/Table';
import Input from '../../components/Input';
import { useModal } from '../../components/modal/modalContext';
import { UserTypes } from '../../helpers/types';

const User = () => {
  const headers = [
    {
      header: 'User ID',
      accessor: 'userId',
    },
    {
      header: 'Name',
      accessor: 'name',
    },
    {
      header: 'Campus',
      accessor: 'campus',
    },
  ];
  const { allUser } = useAuth();
  const [val, setVal] = useState('');
  const [userData, setUserData] = useState<UserTypes[]>([]);

  useEffect(() => {
    const filteredUsers = allUser.filter((user) => user?.userId?.includes(val));
    setUserData(filteredUsers);
  }, [val, allUser]);

  const [rowId, setRowId] = useState('');
  const { isOpen } = useModal();

  useEffect(() => {
    if (rowId !== '') {
      document.getElementById('new-user')?.click();
    }
  }, [rowId]);

  useEffect(() => {
    if (!isOpen && rowId !== '') {
      setRowId('');
    }
  }, [isOpen]);

  return (
    <Container id='user'>
      <div className=' border-b shadow-sm '></div>
      <div className='p-5'>
        <header className='flex justify-between w-full'>
          <span className='inline-flex m-0 items-center'>
            <h1 className='font-semibold'>All Users</h1>
            <Input
              containerClassName='w-44 ml-4 m-0 !border-none'
              placeholder='Search ID '
              value={val}
              onChange={(e) => setVal(e.target.value)}
            />
          </span>
          <Button
            text=' New User'
            ic={<BsPeopleFill />}
            customClassName='rounded-none bg-secondary'
            isModal={<NewUser rowId={rowId} />}
            type='button'
            id='new-user'
          />
        </header>

        <Table
          data={userData
            .filter((x) => x.role === 'user')
            .map((x) => {
              return {
                ...x,
                name: x?.personalData?.lastName + ' ' + x?.personalData?.firstName,
                campus: x?.academicData?.campus,
              };
            })}
          columns={headers as any}
          onEdit={(data: any) => setRowId(data._id)}
          onRemove={function (): void {
            throw new Error('Function not implemented.');
          }}
        />
      </div>
    </Container>
  );
};

export default User;

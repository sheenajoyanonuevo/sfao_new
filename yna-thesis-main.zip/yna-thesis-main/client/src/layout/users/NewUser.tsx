/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from 'react';
import Container from '../../components/Container';
import { academicForm, familyForm, forms } from './forms';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { BsPeopleFill } from 'react-icons/bs';
import { FaGraduationCap } from 'react-icons/fa';
import { IoCloseOutline, IoHeartCircle } from 'react-icons/io5';
import Dropdown from '../../components/Dropdown';
import { useAuth } from '../auth/stores/AuthContext';
import { registerUserByAdmin } from '../auth/api/register.api';
import toast, { Toaster } from 'react-hot-toast';
import { v4 as uuidv4 } from 'uuid';
import { useModal } from '../../components/modal/modalContext';

const NewUser = ({ rowId = '' }: { rowId?: string }) => {
  const [activeMenu, setActiveMenu] = useState(0);
  const { dispatch, allUser } = useAuth();
  const { closeModal } = useModal();
  const [data, setData] = React.useState<any>({ _id: uuidv4() });
  const loadingMenu = [<BsPeopleFill />, <FaGraduationCap />, <IoHeartCircle />];

  const handleNext = () => {
    if (activeMenu < 2) {
      setActiveMenu((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (activeMenu > 0) {
      setActiveMenu((prev) => prev - 1);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;

    setData((prevData: any) => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  useEffect(() => {
    if (rowId) {
      const item = allUser.find((x: any) => x._id === rowId);
      console.log(item);
      if (item?.personalData && item) {
        const { firstName, lastName, middleName, birthday, birthplace, age } = item.personalData;
        const { streetAddres, city, state, zipcode } = item.personalData.address;
        const {
          fatherName,
          fatherAlive,
          fatherAddress,
          fatherOccupation,
          motherName,
          motherAlive,
          motherAddress,
          motherOccupation,
          totalGross,
          numberSibling,
        } = item.familyData;
        const {
          srCode,
          isGraduated,
          program,
          college,
          yearLevel,
          campus,
          gwa,
          honors,
          unitEnrolled,
          scholarshipApplied,
          semester,
          academicYear,
          hasExistingScholar,
          hasExistingScholarName,
        } = item.academicData;
        const formData = {
          _id: item._id,
          firstName,
          lastName,
          middleName,
          birthday,
          birthplace,
          streetAddres,
          city,
          state,
          zipcode,
          age,
          email: item.email,
          userName: item.userId,
          // Academic Data
          srCode,
          isGraduated,
          program,
          college,
          yearLevel,
          campus,
          gwa,
          honors,
          unitEnrolled,
          scholarshipApplied,
          semester,
          academicYear,
          hasExistingScholar,
          hasExistingScholarName,

          // Family Information
          fatherName,
          fatherAlive,
          fatherAddress,
          fatherOccupation,
          motherName,
          motherAlive,
          motherAddress,
          motherOccupation,
          totalGross,
          numberSibling,
          password: item.password,
        };

        setData(formData);
      }
    }
  }, [rowId]);

  const handleSubmit = async () => {
    const address = {
      streetAddress: data?.streetAddress,
      city: data?.city,
      state: data?.state,
      zipcode: data?.zipcode,
    };
    const submitData = {
      ...data,
      password: data.password ? data.password : data.birthday,
      personalData: { ...data, address },
      academicData: data,
      familyData: data,
    };

    console.log(submitData);
    const res = await registerUserByAdmin(submitData);

    if (res.success === false) return toast.error(res.data?.msg || 'Error');
    toast.success(res.msg);
    dispatch({ type: 'ADD_USER', payload: res });

    setTimeout(() => {
      closeModal();
    }, 1500);
  };
  return (
    <Container id='new-user-form'>
      <main className='w-full flex items-center justify-center h-screen'>
        <Toaster />
        <div className='relative w-2/3 p-4 shadow-md bg-white'>
          <div
            className='absolute right-3 top-3 text-red z-30'
            onClick={closeModal}
            id='close-modal'
          >
            <IoCloseOutline />
          </div>
          <div className='relative overflow-hidden'>
            <div
              className='flex transition-transform duration-500 ease-in-out'
              style={{
                transform: `translateX(-${activeMenu * 100}%)`,
                width: '100%',
              }}
            >
              {/* Personal Information */}
              <div className='w-full flex-none'>
                {activeMenu === 0 && (
                  <div className='w-full flex flex-wrap gap-3 content-start items-start'>
                    <h1 className='font-semibold w-full mb-3'>Personal Information</h1>
                    {forms.map((frm, index) => (
                      <Input
                        label={frm.label}
                        key={index}
                        pattern='[0-9]*'
                        name={frm.title}
                        type={frm.type}
                        containerClassName='lg:w-[49%]'
                        required={frm.rquired}
                        checked={data && data[frm.title]}
                        value={(data && data[frm.title]) || ''}
                        onChange={handleChange}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Academic Data */}
              <div className='w-full flex-none'>
                {activeMenu === 1 && (
                  <div className='w-full flex flex-wrap gap-3'>
                    <h1 className='font-semibold w-full mb-3'>Academic Data</h1>
                    {academicForm.map((frm, index) => {
                      if (frm.type === 'select') {
                        return (
                          <div className='lg:w-[49%]'>
                            <Dropdown
                              onChange={(x) => setData({ ...data, [frm.title]: x.target.value })}
                              options={
                                (frm.options &&
                                  frm.options.map((x) => {
                                    return {
                                      value: x,
                                      label: x.toUpperCase(),
                                    };
                                  })) ||
                                []
                              }
                              value={data?.[frm.title]}
                              label={frm.label}
                            />
                          </div>
                        );
                      }
                      return (
                        <Input
                          label={frm.label}
                          key={index}
                          pattern='[0-9]*'
                          checked={data && data[frm.title]}
                          name={frm.title}
                          type={frm.type}
                          containerClassName='lg:w-[49%]'
                          checkboxLabel={frm.checkboxLabel}
                          value={(data && data[frm.title]) || ''}
                          onChange={handleChange}
                        />
                      );
                    })}
                  </div>
                )}
              </div>

              <div className='w-full flex-none'>
                {activeMenu === 2 && (
                  <div className='w-full flex flex-wrap gap-3'>
                    <h1 className='font-semibold w-full mb-3'>Family Information</h1>
                    {familyForm.map((frm, index) => (
                      <Input
                        label={frm.label}
                        key={index}
                        pattern='[0-9]*'
                        checkboxLabel={frm.checkboxLabel}
                        name={frm.title}
                        type={frm.type}
                        containerClassName='lg:w-[49%]'
                        value={(data && data[frm.title]) || ''}
                        onChange={handleChange}
                        checked={data && data[frm.title]}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className='relative flex items-center justify-between mt-5'>
              <div
                className='absolute inset-0 flex items-center justify-between'
                style={{ height: '2px', top: '50%', left: 0, right: 0, backgroundColor: '#d1d5db' }}
              >
                {loadingMenu.map((_, index) => (
                  <div
                    key={index}
                    className={`absolute top-1/2 transform -translate-y-1/2 ${
                      index === 0 ? 'left-0' : index === 1 ? 'left-1/2 transform -translate-x-1/2' : 'right-0'
                    } ${
                      activeMenu === index ? 'bg-primary border-primary' : 'bg-gray-300 border-gray-300'
                    } border-2 rounded-full w-3 h-3`}
                  ></div>
                ))}
              </div>

              {/* Icons */}
              <div className='flex items-center space-x-4 z-10'>
                {loadingMenu.map((Icon, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded-full cursor-pointer ${
                      activeMenu === index ? 'bg-primary text-white' : 'bg-gray-100 text-gray-500'
                    }`}
                    onClick={() => setActiveMenu(index)}
                  >
                    {Icon}
                  </div>
                ))}
              </div>
            </div>

            <footer className='w-full mt-5 flex items-center justify-between'>
              {activeMenu > 0 && (
                <Button
                  text='Previous'
                  customClassName='!px-3 !pr-4 bg-secondary'
                  onClick={handlePrevious}
                />
              )}
              {activeMenu < 2 && (
                <Button
                  text='Next'
                  onClick={handleNext}
                  customClassName='!px-3 !pr-4 bg-secondary'
                />
              )}

              {activeMenu > 1 && (
                <Button
                  text='Save'
                  onClick={handleSubmit as any}
                  customClassName='!px-3 !pr-4 '
                />
              )}
            </footer>
          </div>
        </div>
      </main>
    </Container>
  );
};

export default NewUser;

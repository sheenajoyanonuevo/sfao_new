export const academicForm = [
  {
    label: 'SR Code',
    title: 'srCode',
    type: 'text',
  },
  {
    label: 'Graduation Status',
    title: 'isGraduated',
    type: 'select',
    options: ['undergraduate', 'graduate', 'integrated'],
  },
  {
    label: 'Program',
    title: 'program',
    type: 'text',
  },
  {
    label: 'College',
    title: 'college',
    type: 'text',
  },
  {
    label: 'Year Level',
    title: 'yearLevel',
    type: 'number',
  },
  {
    label: 'Campus',
    title: 'campus',
    type: 'select',
    options: [
      'Pablo Borbon',
      'Alangilan',
      'Lipa',
      'ARASOF - Nasugbu',
      'JPLC Malvar',
      'Balayan',
      'Lemery',
      'Lobo',
      'Rosario',
      'San Juan',
    ],
  },
  {
    label: 'GWA',
    title: 'gwa',
    type: 'number',
  },
  {
    label: 'Honors',
    title: 'honors',
    type: 'text',
    optional: true,
  },
  {
    label: 'Units Enrolled',
    title: 'unitEnrolled',
    type: 'number',
  },
  {
    label: 'Scholarship Applied',
    title: 'scholarshipApplied',
    type: 'text',
  },
  {
    label: 'Semester',
    title: 'semester',
    type: 'text',
  },
  {
    label: 'Academic Year',
    title: 'academicYear',
    type: 'text',
  },
  {
    label: 'Has Existing Scholarship',
    title: 'hasExistingScholar',
    type: 'checkbox',
    checkboxLabel: 'Yes/No',
  },
  {
    label: 'Existing Scholarship Name',
    title: 'hasExistingScholarName',
    type: 'text',
    optional: true,
  },
];

export const familyForm = [
  {
    label: "Father's Name",
    title: 'fatherName',
    type: 'text',
  },
  {
    label: 'Father Alive',
    title: 'fatherAlive',
    type: 'checkbox',
    checkboxLabel: 'Yes/No',
  },
  {
    label: "Father's Address",
    title: 'fatherAddress',
    type: 'text',
  },
  {
    label: "Father's Occupation",
    title: 'fatherOccupation',
    type: 'text',
  },
  {
    label: "Mother's Name",
    title: 'motherName',
    type: 'text',
  },
  {
    label: 'Mother Alive',
    title: 'motherAlive',
    type: 'checkbox',
    checkboxLabel: 'Yes/No',
  },
  {
    label: "Mother's Address",
    title: 'motherAddress',
    type: 'text',
  },
  {
    label: "Mother's Occupation",
    title: 'motherOccupation',
    type: 'text',
  },
  {
    label: 'Total Gross Income',
    title: 'totalGross',
    type: 'text',
  },
  {
    label: 'Number of Siblings',
    title: 'numberSibling',
    type: 'number',
  },
];

export const forms = [
  {
    label: 'First Name',
    title: 'firstName',
    type: 'text',
    rquired: true,
  },
  {
    label: 'Last Name',
    title: 'lastName',
    type: 'text',
    rquired: true,
  },
  {
    label: 'Middle Name',
    title: 'middleName',
    type: 'text',
    optional: true,
  },
  {
    label: 'Birthday',
    title: 'birthday',
    type: 'date',
    optional: true,
    rquired: true,
  },
  {
    label: 'Birthplace',
    title: 'birthplace',
    type: 'text',
    rquired: true,
    optional: true,
  },
  {
    label: 'Street Address',
    title: 'streetAddres',
    type: 'text',
    rquired: true,
  },
  {
    label: 'City',
    title: 'city',
    type: 'text',
    rquired: true,
  },
  {
    label: 'State',
    title: 'state',
    type: 'text',
    rquired: true,
  },
  {
    label: 'Zipcode',
    title: 'zipcode',
    type: 'text',
    rquired: true,
  },
  {
    label: 'Age',
    title: 'age',
    type: 'number',
    rquired: true,
  },
  {
    label: 'Email',
    title: 'email',
    type: 'email',
    rquired: true,
  },

  {
    label: 'Student ID',
    title: 'userName',
    type: 'number',
    rquired: true,
  },
];

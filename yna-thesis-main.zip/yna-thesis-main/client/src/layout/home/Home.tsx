import React, { useEffect } from 'react';
import Appbar from './Appbar';
import Dashboard from '../dashboard/Dashboard';
import Applicant from '../applicants/Applicant';
import Record from '../records/Record';
import User from '../users/User';

const Home = () => {
  const [activeMenu, setActiveMenu] = React.useState<number>(0);

  useEffect(() => {
    const scrollToSection = (id: string) => {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    };

    switch (activeMenu) {
      case 0:
        scrollToSection('dashboard');

        break;
      case 1:
        scrollToSection('applicant');
        break;
      case 2:
        scrollToSection('record');
        break;
      case 3:
        scrollToSection('user');
        break;

      default:
        break;
    }
  }, [activeMenu]);

  // useEffect(() => {
  //   const sections = document.querySelectorAll('section[id]');

  //   const observerOptions = {
  //     root: null,
  //     rootMargin: '0px',
  //     threshold: 0.5,
  //   };

  //   const observer = new IntersectionObserver((entries) => {
  //     entries.forEach((entry) => {
  //       if (entry.isIntersecting) {
  //         const id = entry.target.getAttribute('id');

  //         if (id) {
  //           switch (id) {
  //             case 'dashboard':
  //               setActiveMenu(0);
  //               break;
  //             case 'applicant':
  //               setActiveMenu(1);
  //               break;
  //             case 'record':
  //               setActiveMenu(2);
  //               break;
  //             case 'user':
  //               setActiveMenu(3);
  //               break;
  //             default:
  //               break;
  //           }
  //         }
  //       }
  //     });
  //   }, observerOptions);

  //   sections.forEach((section) => observer.observe(section));

  //   return () => {
  //     sections.forEach((section) => observer.unobserve(section));
  //   };
  // }, []);

  return (
    <div className='bg-gray-50 h-full flex flex-col w-full'>
      <Appbar
        activeMenu={activeMenu}
        setActiveMenu={setActiveMenu}
      />
      <section className='bg-white  h-full w-3/5 shadow-md clear-start overflow-y-auto'>
        {activeMenu === 0 && <Dashboard />}
        {activeMenu === 1 && <Applicant />}
        {activeMenu === 2 && <Applicant  isRecord={true}/>}
        {activeMenu === 3 && <User />}
      </section>
    </div>
  );
};

export default Home;

import React, { useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  ApplicantsIcon,
  ApplicantsRecords,
  HomeIcon,
  LogoutIcon,
  MessageIcon,
  TrashIconSidebar,
  UserIcon,
} from '../../components/Icons';
import { useAuth } from '../auth/stores/AuthContext';
import logo from '../../assets/bsu-logo.png';

const Appbar = ({ activeMenu, setActiveMenu }: { activeMenu: number; setActiveMenu: (num: number) => void }) => {
  const nav = useNavigate();
  const location = useLocation();
  const { user, dispatch } = useAuth();
  const [profile, setProfile] = React.useState<boolean>(true);

  const Menu = useMemo(
    () => [
      { title: 'Home', url: '/', ic: <HomeIcon /> },
      { title: 'Applicants', url: '/applicant', ic: <ApplicantsIcon /> },
      { title: 'Records', url: '/records', ic: <ApplicantsRecords /> },
      { title: 'Users', url: '/user', ic: <UserIcon /> },
      { title: 'Chat', url: '/message', ic: <MessageIcon /> },
      // { title: 'Archive', url: '/archieve', ic: <TrashIconSidebar /> },
    ],
    []
  );

  React.useEffect(() => {
    const index = Menu.findIndex((item) => location.pathname === item.url);
    setActiveMenu(index !== -1 ? index : 0);
  }, [Menu, location]);

  const onLogout = async () => {
    // await axios.get('/api/auth/signout');
    localStorage.removeItem('_appLogin');
    dispatch({ type: 'SIGNOUT' });
    nav('/');
  };

  return (
    <header className='relative w-full'>
      <div
        className={`
         w-16 -ml-20 lg:ml-0 lg:block
        } bg-white shadow  absolute right-0 top-14 w-[20%] z-20 transition-all duration-200 ease-in pt-3`}
      >
        <ul className='w-full mt-10 z-30 flex flex-wrap items-center justify-center'>
          {Menu.map((mItem, index) => (
            <li
              key={index}
              className={`${
                activeMenu === index ? 'bg-primary rounded shadow !text-gray-200 ' : ''
              } w-[40%] text-gray-900 text-sm cursor-pointer hover:bg-primaryLight relative hover:text-white py-2 px-3.5 rounded-md m-2 flex flex-col items-center`}
              onClick={() => setActiveMenu(index)}
            >
              {mItem.ic}
              <span className={`mx-4`}>{mItem.title}</span>
            </li>
          ))}
        </ul>
      </div>

      <nav className='h-[50px] w-full z-20 bg-primary shadow-md flex justify-between items-center'>
        <div className='mx-0 absolute right-1 top-1 flex  text-white items-center h-full -mt-1'>
          <img
            src={user?.profile}
            alt='profile'
            className='h-8 w-8 bg-contain'
            onClick={() => setProfile(!profile)}
          />
          <span className='mx-2  inline-flex gap-2'>
            Hi! {user?.firstName} + {user?.lastName}{' '}
          </span>

          <h2
            onClick={onLogout}
            className='pt-0 flex'
          >
            <span className='mx-2  border-primary inline-flex gap-2'>
              <LogoutIcon />
              Logout
            </span>
          </h2>
        </div>
        <div className='m-1 h-10 inline-flex items-center font-medium gap-x-2 text-white'>
          <img
            src={logo}
            className='h-full'
          />
          <span> Batangas State University</span>
        </div>
      </nav>
    </header>
  );
};

export default Appbar;

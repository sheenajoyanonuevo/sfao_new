import React from 'react';
import Container from '../../components/Container';

const Record = () => {
  return <Container id='record'>Record</Container>;
};

export default Record;

import { ApplicantType } from '../../../helpers/types';

/* eslint-disable @typescript-eslint/no-explicit-any */
const AuthReducer = (state: any, action: { type: any; payload?: any }): any => {
  switch (action.type) {
    case 'SIGNING':
      return {
        ...state,
        user: action.payload,
        isLoggedIn: true,
      };
    case 'GET_TOKEN':
      return {
        ...state,
        token: action.payload,
      };
    case 'GET_USER':
      return {
        ...state,
        user: action.payload,
      };
    case 'SIGNOUT':
      return {
        ...state,
        isLoggedIn: false,
        token: '',
        user: null,
      };
    case 'GET_ALL_USER':
      return {
        ...state,
        allUser: action.payload,
      };

    case 'ADD_USER': {
      const userToAddOrUpdate = action.payload;
      const userIndex = state.allUser.findIndex((user: any) => user._id === userToAddOrUpdate._id);
      if (userIndex >= 0) {
        const updatedUsers = state.allUser.map((user: any, index: number) =>
          index === userIndex ? { ...user, ...userToAddOrUpdate } : user
        );
        return {
          ...state,
          allUser: updatedUsers,
        };
      } else {
        return {
          ...state,
          allUser: [...state.allUser, userToAddOrUpdate],
        };
      }
    }
    case 'GET_ALL_APPLICANT':
      return {
        ...state,
        applicants: action.payload,
      };

    case 'ADD_APPLICANT': {
      const userToAddOrUpdate = action.payload;
      const userIndex = state.applicants?.findIndex((user: ApplicantType) => user._id === userToAddOrUpdate._id);
      if (userIndex >= 0) {
        const updatedUsers = state.applicants.map((user: ApplicantType, index: number) =>
          index === userIndex ? { ...user, ...userToAddOrUpdate } : user
        );
        return {
          ...state,
          applicants: updatedUsers,
        };
      } else {
        return {
          ...state,
          applicants: [...state.applicants, userToAddOrUpdate],
        };
      }
    }

    default:
      return state;
  }
};

export default AuthReducer;

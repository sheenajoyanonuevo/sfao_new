/* eslint-disable @typescript-eslint/no-explicit-any */
import axios from 'axios';
import { API_ENDPOINT } from '../../../config/API';

export const loginUser = async (data: any) => {
  try {
    const response = await axios.post(`${API_ENDPOINT}/api/auth/login`, data);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      return {
        success: false,
        status: error.response?.status,
        message: error.message,
        data: error.response?.data,
      };
    } else {
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }
};

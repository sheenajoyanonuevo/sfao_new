/* eslint-disable @typescript-eslint/no-explicit-any */
import axios, { InternalAxiosRequestConfig } from 'axios';
import { API_ENDPOINT } from '../../../config/API';

const USER_API = axios.create({ baseURL: API_ENDPOINT });

USER_API.interceptors.request.use((req: InternalAxiosRequestConfig<any>) => {
  const storage = sessionStorage.getItem('token');
  if (storage !== null && storage) {
    req.headers.Authorization = `Bearer ${storage}`;
  }
  return req;
});

export const getUser = async () => {
  try {
    const response = await USER_API.get(`/api/auth/user`);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      return {
        success: false,
        status: error.response?.status,
        message: error.message,
        data: error.response?.data,
      };
    } else {
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }
};


export const getAllUser = async () => {
  try {
    const response = await USER_API.get(`/api/auth/all-user`);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      return {
        success: false,
        status: error.response?.status,
        message: error.message,
        data: error.response?.data,
      };
    } else {
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }
};

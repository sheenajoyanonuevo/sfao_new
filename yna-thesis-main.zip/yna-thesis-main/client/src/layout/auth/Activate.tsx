import { useEffect, useState } from 'react';
import toast, { CheckmarkIcon, Toaster } from 'react-hot-toast';
import { useLocation, useNavigate } from 'react-router-dom';

import { activateUser } from './api/activate.api';
import Button from '../../components/Button';

function Activate() {
  const location = useLocation();
  const nav = useNavigate();
  const [activated, setIsActivated] = useState(false);
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const token = searchParams.get('token');

    const handleActivate = async () => {
      const res = await activateUser({ activation_token: token });

      if (res.success === false || res.msg ==="jwt malformed") {
        setIsActivated(false);
        return toast.error(res.data?.msg || 'Error');
      }
      toast.success('Please Check your email fo activation');

      setTimeout(() => {
        nav(-1);
      }, 1500);
    };

    handleActivate();
  }, [location.search]);

  if(!activated){
    return(
      <p>Account Already activated or invalid token</p>
    )
  }

  return (
    <main className='flex-1 flex h-full justify-center items-center'>
      <Toaster />
      <div className='lg:w-1/2  bg-white border flex  p-4 rounded-shadow rounded-md flex-wrap gap-y-2 flex-col items-center justify-center'>
        <h1 className='text-lg mb-4 font-light text-center border-b w-full pb-3'>Verify Account</h1>

        <p className='text-center text-sm opacity-80 text-black m-4 mb-0 inline-flex items-center gap-3'>
          <CheckmarkIcon className='m-0' /> Account Succesfully Verified
        </p>

        <Button
          text='  Proceed to Login now'
          customClassName='mt-2'
          onClick={() => nav('/')}
        />
      </div>
    </main>
  );
}

export default Activate;

/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { FaRegQuestionCircle } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import { registerUser } from './api/register.api';
import toast, { Toaster } from 'react-hot-toast';

const Register = () => {
  const [data, setData] = React.useState({
    email: '',
    firstName: '',
    lastName: '',
    password: '',
    cfPassword: '',
  });

  const nav = useNavigate();

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    const res = await registerUser(data);

    if (res.success === false) return toast.error(res.data?.msg || 'Error');
    toast.success('Please Check your email fo activation');

    setTimeout(() => {
      nav(-1);
    }, 1500);
  };

  return (
    <main className='flex-1 flex h-full justify-center items-center'>
      <Toaster />
      <form
        onSubmit={handleSubmit}
        className='lg:w-1/2  bg-white border flex  p-4 rounded-shadow rounded-md flex-wrap gap-y-2'
      >
        <h1 className='font-medium w-full border-b pb-2 mb-3 '>Registration Form</h1>

        <Input
          value={data.firstName}
          type='text'
          label='Fist Name'
          containerClassName='xl:w-[50%] !m-0'
          onChange={(event) => setData({ ...data, firstName: event.target.value })}
        />

        <Input
          value={data.lastName}
          type='text'
          containerClassName='xl:w-[48%] xl:ml-3 m-0'
          label='Last Name'
          onChange={(event) => setData({ ...data, lastName: event.target.value })}
        />
        <Input
          value={data.email}
          type='email'
          label='Email'
          onChange={(event) => setData({ ...data, email: event.target.value })}
        />
        <Input
          type='password'
          label='Password'
          value={data.password}
          containerClassName='xl:w-[50%] !m-0'
          onChange={(event) => setData({ ...data, password: event.target.value })}
        />
        <Input
          type='password'
          label='Confirm Password'
          value={data.cfPassword}
          containerClassName='xl:w-[48%] xl:ml-3 m-0'
          onChange={(event) => setData({ ...data, cfPassword: event.target.value })}
        />
        <Button
          text='Create Account'
          type='submit'
          customClassName='!w-full mt-2'
        />

        <hr />
        <footer className='m-0 inline-flex gap-x-2 mt-2'>
          <Button
            text='Back to Login'
            customClassName='!bg-primaryLight !text-slate-800 hover:!bg-primary hover:!text-white !text-xs'
            ic={<FaRegQuestionCircle />}
            onClick={() => nav('/')}
            type='button'
          />
        </footer>
      </form>
    </main>
  );
};

export default Register;

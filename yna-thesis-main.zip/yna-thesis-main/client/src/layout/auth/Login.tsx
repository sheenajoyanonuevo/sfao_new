/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import Input from '../../components/Input';
import Button from '../../components/Button';
import { FaRegQuestionCircle } from 'react-icons/fa';
import { IoMailUnreadOutline } from 'react-icons/io5';
import { useNavigate } from 'react-router-dom';
import { loginUser } from './api/login.api';
import toast, { Toaster } from 'react-hot-toast';

const Login = () => {
  const [data, setData] = React.useState({
    email: '',
    password: '',
  });

  const nav = useNavigate();

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    const res = await loginUser(data);

    if (res.success === false) return toast.error(res.data?.msg || 'Error');
    toast.success(res.msg);

    sessionStorage.setItem('token', res.token);
    setTimeout(() => {
      window.location.reload();
    }, 1500);
  };

  return (
    <main className='flex-1 flex h-full justify-center items-center'>
      <Toaster />
      <form
        onSubmit={handleSubmit}
        className='w-96 bg-white border gap-y-2 flex flex-col p-4 rounded-shadow ounded-md'
      >
        <h1 className='font-medium '>Please Login</h1>
        <hr />
        <Input
          value={data.email}
          type='email'
          label='Email'
          onChange={(event) => setData({ ...data, email: event.target.value })}
        />
        <Input
          type='password'
          label='Password'
          value={data.password}
          onChange={(event) => setData({ ...data, password: event.target.value })}
        />
        <p className='text-xs'>* Password is case sensitive</p>
        <Button
          text='Sign In'
          customClassName='!w-full mb-2'
          type='submit'
        />

        <div className='relative w-full border-t border-gray-300 text-sm'>
          <p className='absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white px-2'>or</p>
        </div>

        <Button
          text='New Account'
          customClassName='!w-full my-2 !bg-secondaryLight !text-slate-800 hover:!bg-secondary hover:!text-white'
          type='button'
          onClick={() => nav('/register')}
        />
        <hr />
        <footer className='m-0 inline-flex gap-x-2 mt-2'>
          <Button
            text='Forgot Password? Click Here'
            customClassName='!bg-primaryLight !text-slate-800 hover:!bg-primary hover:!text-white !text-xs'
            ic={<FaRegQuestionCircle />}
            type='button'
          />
          <Button
            text='Contact Us'
            customClassName='!bg-primaryLight !text-slate-800 hover:!bg-primary hover:!text-white !text-xs flex-1'
            ic={<IoMailUnreadOutline />}
            type='button'
          />
        </footer>
      </form>
    </main>
  );
};

export default Login;

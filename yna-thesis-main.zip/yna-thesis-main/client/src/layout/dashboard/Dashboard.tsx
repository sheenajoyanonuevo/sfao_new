import React from 'react';
import Container from '../../components/Container';

const Dashboard = () => {
  return <Container id='dashboard'>Dashboard</Container>;
};

export default Dashboard;

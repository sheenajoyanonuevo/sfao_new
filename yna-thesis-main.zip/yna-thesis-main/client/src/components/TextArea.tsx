import React, { ReactNode, TextareaHTMLAttributes } from 'react';

interface InputProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  customClassName?: string;
  containerClassName?: string;
  value?: string | number;
  icon?: ReactNode;
  handleShowPassword?: () => void;
  id?: string;
}

const TextArea: React.FC<InputProps> = ({
  label,
  error,
  containerClassName,
  value,
  icon,
  handleShowPassword,
  id,
  ...rest
}) => {
  return (
    <div className={`${containerClassName} relative w-full`}>
      <div className='relative'>
        {label && (
          <label
            htmlFor={id}
            className='block mb-2 text-sm font-medium'
          >
            {label}
          </label>
        )}
        <textarea
          {...rest}
          rows={5}
          name={rest.name}
          id={id}
          className={`border text-slate-900 rounded-lg focus:outline-primary focus:ring-primary focus:border-primary block w-full px-2.5 py-1.5 `}
          placeholder=' '
          value={value}
        />
        {error && <p className='text-xs ml-1 mt-1 text-red-500'>{error}</p>}
        {icon && (
          <p
            className='text-gray-400 mr-2 cursor-pointer absolute right-2 top-1/2 transform -translate-y-1/2'
            onClick={handleShowPassword}
          >
            {icon}
          </p>
        )}
      </div>
    </div>
  );
};

export default TextArea;

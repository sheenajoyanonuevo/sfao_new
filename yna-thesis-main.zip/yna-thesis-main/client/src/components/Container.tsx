import React, { ReactNode } from 'react';

const Container = ({ children, id }: { children: ReactNode; id: string }) => {
  return (
    <section
      id={id}
      className='min-h-[calc(100dvh-50px)] overflow-y-auto w-full'
    >
      {children}
    </section>
  );
};

export default Container;

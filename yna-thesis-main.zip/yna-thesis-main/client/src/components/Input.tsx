import React, { InputHTMLAttributes, ReactNode } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  customClassName?: string;
  containerClassName?: string;
  value?: string | number;
  icon?: ReactNode;
  handleShowPassword?: () => void;
  id?: string;
  checkboxLabel?: string;
}

const Input: React.FC<InputProps> = ({
  label,
  error,
  customClassName,
  containerClassName,
  value,
  icon,
  handleShowPassword,
  id,
  type,
  checkboxLabel,
  ...rest
}) => {
  return (
    <div className={`${containerClassName} m-0 w-full relative`}>
      {label && (
        <label
          htmlFor={id}
          className='block mb-2 text-sm font-medium'
        >
          {label} {rest.required && "*"}
        </label>
      )}
      <div className={`flex items-center ${type === 'checkbox' ? 'space-x-2 border p-[7px] rounded-md' : ''}`}>
        {type === 'checkbox' && (
          <>
            <input
              type='checkbox'
              id={id}
              className='form-checkbox'
              {...rest}
            />
            {checkboxLabel && <p className='text-sm'>{checkboxLabel}</p>}
          </>
        )}
        {type !== 'checkbox' && (
          <>
            <input
              {...rest}
              type={type}
              name={rest.name}
              id={id}
              value={value}
              className={`border text-slate-900 rounded-lg focus:outline-primary focus:ring-primary focus:border-primary block w-full px-2.5 py-1.5 ${customClassName}`}
              placeholder={rest.placeholder}
            />
          </>
        )}
        {icon && (
          <p
            className='text-gray-400 mr-2 cursor-pointer absolute right-1 top-[18px]'
            onClick={handleShowPassword && handleShowPassword}
          >
            {icon}
          </p>
        )}
      </div>
      {error && <p className='text-xs ml-1 mt-1 text-red'>{error}</p>}
    </div>
  );
};

export default Input;

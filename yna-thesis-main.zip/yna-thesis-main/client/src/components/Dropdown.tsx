import React, { SelectHTMLAttributes, ReactNode, useState } from 'react';

interface DropdownProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  customClassName?: string;
  containerClassName?: string;
  options: { value: string | number; label: string }[];
  icon?: ReactNode;
  id?: string;
  value?: string | number;
}

const Dropdown: React.FC<DropdownProps> = ({
  label,
  error,
  containerClassName,
  options,
  icon,
  id,
  value,
  ...rest
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleDropdown = () => setIsOpen(!isOpen);

  return (
    <div className={`${containerClassName} relative w-full -ml-1`}>
      {label && (
        <label
          htmlFor={id}
          className={`block mb-2 text-sm font-medium transition-transform duration-300 transform bg-white peer-focus:-translate-y-4 peer-focus:scale-75`}
        >
          {label} {rest.required && "*"}
        </label>
      )}
      <div className='relative'>
        <input
          readOnly
          value={value ? options.find(option => option.value === value)?.label : label}
          onClick={toggleDropdown}
          className={`block w-full px-2.5 py-1.5 border text-slate-900 rounded-lg focus:outline-primary focus:ring-primary focus:border-primary ${error ? 'border-red-500' : 'border-gray-300'} ${icon ? 'pr-10' : ''}`}
          id={id}
        />
        {isOpen && (
          <div className='absolute top-full left-0 z-10 mt-1 w-full max-h-52 overflow-y-auto bg-white border border-gray-300 rounded-lg shadow-lg'>
            <ul>
              {options.map((option) => (
                <li
                  key={option.value}
                  className='p-2 hover:bg-gray-200 cursor-pointer text-sm'
                  onClick={() => {
                    if (rest.onChange) {
                      // Trigger the change event with selected option
                      rest.onChange({ target: { value: option.value } } as React.ChangeEvent<HTMLSelectElement>);
                    }
                    setIsOpen(false);
                  }}
                >
                  {option.label}
                </li>
              ))}
            </ul>
          </div>
        )}
        {icon && (
          <p
            className='text-gray-400 cursor-pointer absolute right-2 top-1/2 transform -translate-y-1/2'
            onClick={() => {}}
          >
            {icon}
          </p>
        )}
      </div>
      {error && <p className='text-xs mt-1 text-red-500'>{error}</p>}
    </div>
  );
};

export default Dropdown;

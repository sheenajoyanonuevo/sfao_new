/* eslint-disable @typescript-eslint/no-explicit-any */
import React from 'react';
import { TableProps } from '../helpers/types';
const Table = <T,>({ data, columns, onEdit, title, isRecord }: TableProps<T> & { isRecord?: boolean }): JSX.Element => {
  return (
    <div className='relative overflow-x-auto mt-3 pr-2'>
      <table className='w-full text-sm text-left rtl:text-right text-gray-500'>
        <thead className='text-xs text-white bg-primaryLight'>
          <tr>
            {columns.map((column, index) => (
              <th
                scope='col'
                className='px-6 py-2'
                key={index}
              >
                {column.header}
              </th>
            ))}

            <th
              scope='col'
              className='px-6 py-2'
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody>
          {data.length === 0 ? (
            <tr>
              <td className='!pl-2 !pt-6 font-bold'>No Data Found</td>
            </tr>
          ) : (
            data.map((row, rowIndex) => (
              <tr
                key={rowIndex}
                className='bg-white border-b'
              >
                {columns.map((column, columnIndex) => (
                  <td
                    key={columnIndex}
                    className={`px-6 py-3 font-medium text-gray-900 whitespace-nowrap`}
                  >
                    <span
                      className={`
                        ${title === 'applicant' && 'py-1 px-2 rounded-sm '}
                       `}
                    >
                      {column.render
                        ? column.render(row[column.accessor], row)
                        : (row[column.accessor] as React.ReactNode)}
                    </span>
                  </td>
                ))}
                <td className='px-6 py-3 font-medium text-gray-900 whitespace-nowrap'>
                  <button
                    onClick={() => onEdit(row)}
                    className='text-secondary mr-5'
                  >
                    {title === 'applicant' ? 'View Application' : 'Edit'}
                  </button>
                  {!isRecord && <button className='text-red font-medium'>Delete</button>}
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;

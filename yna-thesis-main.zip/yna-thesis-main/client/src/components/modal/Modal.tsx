import { useModal } from './modalContext';

const Modal = () => {
  const { isOpen, content } = useModal();

  if (!isOpen) return false;

  return (
    <div className='fixed inset-0 w-screen h-screen  z-20 transparent transition-all duration-150'>
      <div
        className=' w-full flex items-center justify-center h-full backdrop-blur-sm'
        onClick={(e) => e.stopPropagation()}
      >
        {content}
      </div>
    </div>
  );
};

export default Modal;

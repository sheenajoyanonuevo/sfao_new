import React, { Suspense, useCallback, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './layout/auth/Login';
import { useAuth } from './layout/auth/stores/AuthContext';
import Register from './layout/auth/Register';
import Activate from './layout/auth/Activate';
import { getAllUser, getUser } from './layout/auth/api/get.info.api';
import toast from 'react-hot-toast';
import Home from './layout/home/Home';
import Modal from './components/modal/Modal';
import { getAllApplicant } from './layout/applicants/api';
const App = () => {
  const { isLoggedIn, user, dispatch, allUser } = useAuth();

  useEffect(() => {
    const token = sessionStorage.getItem('token');
    if (token) {
      const handlegetInfo = async () => {
        const res = await getUser();
        if (res.success === false) return toast.error(res.data?.msg || 'Error');
        dispatch({ type: 'SIGNING', payload: res });

        const getAllUsers = await getAllUser();
        dispatch({ type: 'GET_ALL_USER', payload: getAllUsers });

        const getAllApplicants = await getAllApplicant('2024-2025');
        dispatch({ type: 'GET_ALL_APPLICANT', payload: getAllApplicants });

        toast.success(res.msg);
      };
      handlegetInfo();
    }
  }, []);

  console.log(allUser);

  const renderRoutes = useCallback(() => {
    return (
      <Routes>
        <Route
          path='/'
          element={isLoggedIn ? <Home /> : <Login />}
        />
        <Route
          path='/register'
          element={isLoggedIn ? null : <Register />}
        />
        <Route
          path='/activate'
          element={isLoggedIn ? null : <Activate />}
        />
        {/* <Route
          path='/activate'
          element={isLoggedIn ? null : <ActivateLayout />}
        />
        <Route
          path='/login'
          element={isLoggedIn ? null : <LoginLayout />}
        /> */}
      </Routes>
    );
  }, [isLoggedIn, user?.role]);

  return (
    <div className='  overflow-y-hidden overflow-x-hidden h-[100dvh] w-screen'>
      <Suspense fallback={<div>Loading...</div>}>{renderRoutes()}</Suspense>
      <Modal />
    </div>
  );
};

export default App;

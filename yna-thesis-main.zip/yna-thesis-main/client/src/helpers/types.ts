/* eslint-disable @typescript-eslint/no-explicit-any */
export type TableProps<T> = {
  data: T[];
  columns: Column<T>[];
  onEdit: (item: T) => void;
  onRemove: (item: T) => void;
  title?: string;
};

export type Column<T> = {
  header: string;
  accessor: keyof T;
  render?: (value: any, row: T) => React.ReactNode;
};

//address type
export interface AddressTypes {
  streetAddres: string;
  city: string;
  state: string;
  zipcode: string;
  latitude: number;
  longitude: number;
}

// personal
export interface PersonalTypes {
  firstName: string;
  lastName: string;
  middleName?: string;
  birthday?: string;
  birthplace?: string;
  address: AddressTypes;
  profile: string;
  age: number;
  email: string;
}

//academic
export interface AcademicDataTypes {
  srCode: string;
  isGraduated: 'undergraduate' | 'graduate' | 'integrated';
  program: string;
  college: string;
  yearLevel: number;
  campus: string;
  gwa: number;
  honors?: string;
  unitEnrolled: number;
  scholarshipApplied: string;
  semester: string;
  academicYear: string;
  hasExistingScholar: boolean;
  hasExistingScholarName: string;
}

export interface FamilyData {
  fatherName: string;
  fatherAlive: boolean;
  fatherAddress: string;
  fatherOccupation: string;
  motherName: string;
  motherAlive: boolean;
  motherAddress: string;
  motherOccupation: string;
  totalGross: string;
  numberSibling: number;
}

export interface UserTypes {
  password: string;
  role: 'admin' | 'user';
  userId: string;
  _id: string;
  personalData: PersonalTypes;
  email: string;
  academicData: AcademicDataTypes;
  familyData: FamilyData;
}

export interface ApplicantType {
  _id: string;
  applicantId: string;
  status: string;
  schoolId: string;
  enrollmentForm: string;
  recentGrades: string;
  votersReigstration?: string;
  psa: string;
  schoolYear: string;
  statusUpdate: {
    status: string;
    date: Date;
    reason?: string;
    approvedBy?: string;
  }[];
}

export const statusColors: Record<string, string> = {
  pending: 'bg-yellow',
  approved: 'bg-green-500',
  cancelled: 'bg-red',
  rejected: 'bg-red',
};

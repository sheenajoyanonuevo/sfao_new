export const API_ENDPOINT = import.meta.env.VITE_API_URL;

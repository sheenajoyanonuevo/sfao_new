import mongoose, { Schema, model } from 'mongoose';
import { UserTypes } from '../type';

const addressSchema = new Schema(
  {
    streetAddres: String,
    city: String,
    state: String,
    zipcode: String,
    latitude: Number,
    longitude: Number,
  },
  { _id: false }
);

const personalSchema = new Schema(
  {
    firstName: String,
    lastName: String,
    middleName: { type: String, required: false },
    birthday: { type: String, required: false },
    birthplace: { type: String, required: false },
    address: addressSchema,
    profile: {
      type: String,
      default: 'https://res.cloudinary.com/dyhsose70/image/upload/v1696562163/avatar_ko5htr.png',
    },
    age: Number,
    email: String,
  },
  { _id: false }
);

const academicDataSchema = new Schema(
  {
    srCode: String,
    isGraduated: { type: String, enum: ['undergraduate', 'graduate', 'integrated'] },
    program: String,
    college: String,
    yearLevel: Number,
    campus: String,
    gwa: Number,
    honors: { type: String, required: false },
    unitEnrolled: Number,
    scholarshipApplied: String,
    semester: String,
    academicYear: String,
    hasExistingScholar: Boolean,
    hasExistingScholarName: String,
  },
  { _id: false }
);

const familyDataSchema = new Schema(
  {
    fatherName: String,
    fatherAlive: Boolean,
    fatherAddress: String,
    fatherOccupation: String,
    motherName: String,
    motherAlive: Boolean,
    motherAddress: String,
    motherOccupation: String,
    totalGross: String,
    numberSibling: Number,
  },
  { _id: false }
);

const userSchema = new Schema<UserTypes>(
  {
    password: String,
    role: { type: String, enum: ['admin', 'user'], default: 'user' },
    userId: String,
    personalData: personalSchema,
    academicData: academicDataSchema,
    familyData: familyDataSchema, email: String,
  },
  { timestamps: true }
);

export default model<UserTypes>('User', userSchema);

// models/ApplicantModel.ts

import mongoose, { Schema, model } from 'mongoose';
import { ApplicantType } from '../type';

const statusUpdateSchema = new Schema(
  {
    status: { type: String, required: true },
    date: { type: Date, required: true },
    reason: { type: String },
  },
  { _id: false }
);

const applicantSchema = new Schema<ApplicantType>(
  {
    applicantId: { type: String, required: true, unique: true },
    status: { type: String, enum: ['pending', 'approved', 'cancelled', 'rejected'], default: 'pending' },
    schoolId: { type: String },
    enrollmentForm: { type: String },
    recentGrades: { type: String },
    votersReigstration: { type: String },
    psa: { type: String },
    schoolYear: String,
    statusUpdate: [statusUpdateSchema],
    approvedBy: String,
  },
  { timestamps: true }
);

export default model<ApplicantType>('Applicant', applicantSchema);

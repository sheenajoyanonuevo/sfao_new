import mongoose, { Schema, model } from 'mongoose';
import { BranchTypes } from '../type';
const branchSchema = new Schema<BranchTypes>(
  {
    branchName: String,
    ownerId: { type: mongoose.Schema.ObjectId, ref: 'user' },
    status: Boolean,
  },
  { timestamps: true }
);
export default model<BranchTypes>('Branch', branchSchema);

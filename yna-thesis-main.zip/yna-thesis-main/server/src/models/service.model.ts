import mongoose, { Schema, model } from 'mongoose';
import { ServiceTypes } from '../type';
const serviceSchema = new Schema<ServiceTypes>(
  {
    serviceName: String,
    serviceDescription: String,
    servicePrice: Number,
    branchId: { type: mongoose.Schema.ObjectId, ref: 'Branch' },
    status: Boolean,
  },
  { timestamps: true }
);
export default model<ServiceTypes>('Service', serviceSchema);

import mongoose from 'mongoose';

//address type
export interface AddressTypes {
  streetAddres: string;
  city: string;
  state: string;
  zipcode: string;
  latitude: number;
  longitude: number;
}

// personal
export interface PersonalTypes {
  firstName: string;
  lastName: string;
  middleName?: string;
  birthday?: string;
  birthplace?: string;
  address: AddressTypes;
  profile: string;
  age: number;
}

//academic
export interface AcademicDataTypes {
  srCode: string;
  isGraduated: 'undergraduate' | 'graduate' | 'integrated';
  program: string;
  college: string;
  yearLevel: string;
  campus: string;
  gwa: number;
  honors?: string;
  unitEnrolled: number;
  scholarshipApplied: string;
  semester: string;
  academicYear: string;
  hasExistingScholar: boolean;
  hasExistingScholarName: string;
}

export interface FamilyData {
  fatherName: string;
  fatherAlive: boolean;
  fatherAddress: string;
  fatherOccupation: string;
  motherName: string;
  motherAlive: boolean;
  motherAddress: string;
  motherOccupation: string;
  totalGross: string;
  numberSibling: number;
}

//user types
export interface UserTypes {
  password: string;
  role: 'admin' | 'user';
  userId: string;
  personalData: PersonalTypes;
  email: string;
  academicData: AcademicDataTypes;
  familyData: FamilyData;
}

export interface TransactionTypes {
  serviceId: mongoose.ObjectId | string;
  branchId: mongoose.ObjectId | string;
  userId: mongoose.ObjectId | string;
  quantity: number;
  total: number;
  date: Date;
}

export interface ApplicantType {
  applicantId: string;
  status: string;
  schoolId: string;
  enrollmentForm: string;
  recentGrades: string;
  votersReigstration?: string;
  psa: string;
  schoolYear: string;
  statusUpdate: {
    status: string;
    date: Date;
    reason?: string;
  }[];
  approvedBy: string;
}

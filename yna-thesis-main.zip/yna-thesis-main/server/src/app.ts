import express, { Express } from 'express';
import dotenv from 'dotenv';
import conn from './config/dbConnection';
import { createServer } from 'http';
import userRoute from './routes/user.routes';
import applicantRoute from './routes/applicant.routes';
import { Server } from 'socket.io';
const cors = require('cors');
dotenv.config();
const app: Express = express();
const port = 5000;

const server = createServer(app);
const corsOptions = {
  origin: 'http://localhost:5173',
};

const io = new Server(server, {
  cors: {
    origin: [corsOptions.origin],
  },
});

app.use(
  cors({
    origin: 'http://localhost:5173',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  })
);

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '5000mb', extended: true }));

app.use('/api/auth', userRoute);
app.use('/api/applicant', applicantRoute);

conn()
  .then(() => {
    server.listen(port, () => {
      console.log(`Express is listening at http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error('Error connecting to DB:', err);
  });

import express from 'express';
import protect from '../middlewares/authMiddleWare';
import { newServices } from '../controllers/serviceContoller';
const router = express.Router();

router.post('/create', protect, newServices);
export default router;

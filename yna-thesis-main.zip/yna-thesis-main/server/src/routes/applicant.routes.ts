import express from 'express';
import protect from '../middlewares/authMiddleWare';
import { getApplicant, newApplicant } from '../controllers/applicatController';

const router = express.Router();

router.post('/create', protect, newApplicant);
router.get('/:id', protect, getApplicant);
export default router;

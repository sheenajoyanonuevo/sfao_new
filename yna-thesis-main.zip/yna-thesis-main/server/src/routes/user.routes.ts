import express from 'express';
import {
  activate,
  editUser,
  getAllUsers,
  getUser,
  login,
  register,
  registerUser,
} from '../controllers/user.controller';
import protect from '../middlewares/authMiddleWare';
const router = express.Router();

router.post('/register', register);
router.post('/activate', activate);
router.post('/login', login);
router.get('/user', protect, getUser);
router.patch('/update-user', protect, editUser);
router.post('/add-user', protect, registerUser);
router.get('/all-user', protect, getAllUsers);
export default router;

const nodemailer = require('nodemailer');
const { google } = require('googleapis');
const { OAuth2 } = google.auth;
const OAUTH_PLAYGROUND = 'https://developers.google.com/oauthplayground';
require('dotenv').config();

const { G_CLIENT_ID, G_CLIENT_SECRET, G_REFRESH_TOKEN, ADMIN_EMAIL } = process.env;

const oauth2client = new OAuth2(G_CLIENT_ID, G_CLIENT_SECRET, G_REFRESH_TOKEN, OAUTH_PLAYGROUND);

const sendRegistration = (to, password_unhash, name, url) => {
  oauth2client.setCredentials({
    refresh_token: G_REFRESH_TOKEN,
  });
  const accessToken = oauth2client.getAccessToken();
  const smtpTransport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      type: 'OAuth2',
      user: ADMIN_EMAIL,
      clientId: G_CLIENT_ID,
      clientSecret: G_CLIENT_SECRET,
      refreshToken: G_REFRESH_TOKEN,
      accessToken,
    },
  });

  const mailOptions = {
    from: 'Test',
    to: to,
    password_unhash: password_unhash,
    url: url,
    subject: 'VERIFY ACCOUNT',
    html: `
    <!DOCTYPE html>
<html>
<head>
<title>Title of the document</title>
</head>

<body>
 <h1>Verify your email address</h1>
                <h2>Dear ${name},</h2>
                <h2>
                  To activate and start using your account, you need to confirm
                  your email address.
                </h2> <button>
                  <a href="${url}">Activate Account</a>
                </button>
                 <h2>Your Login Credentials are as follows:</h2>
                <h2>Access Email: ${to}</h2>
                <h2>Password: ${password_unhash}</h2>
</body>

</html>`,
  };
  smtpTransport.sendMail(mailOptions, (err, info) => {
    if (err) return { err };
    return info;
  });
};

export { sendRegistration };

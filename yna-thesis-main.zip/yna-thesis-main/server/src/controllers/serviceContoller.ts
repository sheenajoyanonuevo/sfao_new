import expressAsyncHandler from 'express-async-handler';
import { CustomRequest } from './user.controller';
import Service from '../models/service.model';

export const newServices = expressAsyncHandler(async (req: CustomRequest, res) => {
  const data = req.body;
  try {
    const createService = await Service.create(data);
    res.status(200).json(createService);
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

export const updateServices = expressAsyncHandler(async (req: CustomRequest, res) => {
  const data = req.body;
  try {
    const updateBranch = await Service.findByIdAndUpdate(req.params.id, data, { new: true });
    res.status(200).json(updateBranch);
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

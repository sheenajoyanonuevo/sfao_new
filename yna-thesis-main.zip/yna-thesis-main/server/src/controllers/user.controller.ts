import expressAsyncHandler from 'express-async-handler';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/user.model';
import { sendRegistration } from '../helpers/sendMail';

import { Request } from 'express';
import mongoose from 'mongoose';
export interface CustomRequest extends Request {
  user?: {
    _id: string;
    name: string;
    role: string;
  };
}

//generate token
const generateToken = (id: string): string => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '24h',
  });
};

const activationToken = (payload: any) => {
  return jwt.sign(payload, process.env.ACTIVATION_TOKEN, {
    expiresIn: '2h',
  });
};

//register
export const register = expressAsyncHandler(async (req, res) => {
  try {
    const data = req.body;

    const { email, password, firstName, lastName } = data;

    if (!firstName || !lastName || !email || !password) {
      res.status(400);
      throw new Error('Please Fill all the Fields');
    }

    const isUserEmail = await User.findOne({ email });

    if (isUserEmail) {
      res.status(400);
      throw new Error('User already exists');
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    const userData = {
      ...data,
      password: hashedPassword,
    };

    const activation_token = activationToken(userData);
    const url = `http://localhost:3001?token=${activation_token}`;
    const name = firstName + ' ' + lastName;
    sendRegistration(email, password, name, url);
    res.status(200).json({ msg: 'Please check your email for verification' });
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

//activate
export const activate = expressAsyncHandler(async (req, res) => {
  try {
    const { activation_token } = req.body;
    console.log(activation_token);
    const user = jwt.verify(activation_token, process.env.ACTIVATION_TOKEN);

    if (!user) {
      res.status(400);
      throw new Error('Invalid Token');
    }

    const newUser = await User.create(user);
    if (newUser) {
      res.status(200).json(newUser);
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: error.message });
  }
});

//login
export const login = expressAsyncHandler(async (req: any, res) => {
  try {
    const data = req.body;
    const { email, password } = data;
    if (!email || !password) {
      res.status(400);
      throw new Error('Please fill all the fields');
    }
    const user = await User.findOne({ email });
    if (!user) res.status(400).json({ msg: 'User not Found' });
    if (user && (await bcrypt.compare(password, user.password))) {
      res.status(200).json({
        role: user.role,
        _id: user._id,
        token: generateToken(String(user._id)),
      });
    } else {
      res.status(500).json({ msg: 'Invalid Email or Password' });
    }
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

//account-details
export const getUser = expressAsyncHandler(async (req: CustomRequest, res) => {
  if (req.user) {
    const user = await User.findById(req.user._id).select('-password');
    return res.status(200).json(user);
  } else {
    res.status(404).json({ msg: 'User not found' });
  }
});

//edit
export const editUser = expressAsyncHandler(async (req: CustomRequest, res) => {
  const data = req.body;

  try {
    const updateuser = await User.findByIdAndUpdate(req.user._id, data, { new: true });
    res.status(200).json(updateuser);
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

//register
export const registerUser = expressAsyncHandler(async (req, res) => {
  try {
    const data = req.body;

    if (!mongoose.isValidObjectId(data._id)) {
      const { email, firstName, userName, lastName } = data;

      if (!firstName || !lastName || !email) {
        res.status(400);
        throw new Error('Please Fill all the Fields');
      }

      const isUserEmail = await User.findOne({ email });
      const isUsername = await User.findOne({ userId: userName });

      console.log(isUserEmail, isUsername);
      if (isUsername || isUserEmail) {
        res.status(400);
        throw new Error('User already existss');
      }

      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(data.birthday, salt);
      delete data._id;
      const newUser = await User.create({ ...data, password: hashedPassword, userId: userName });

      res.status(200).json({ msg: 'User Added Succesfully', newUser });
    } else {
      const updateuser = await User.findByIdAndUpdate(data._id, { ...data, userId: data.userName }, { new: true });
      res.status(200).json(updateuser);
    }
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});


export const getAllUsers = async (req: CustomRequest, res) => {
  const allUser = await User.find({}).sort({ createdAt: -1 });
  console.log(allUser)
  // const filterUser = allUser.filter((x) => (x as any)._id.toString() !== req.user._id);
  return res.status(200).json(allUser);
};


//forgot-password
//reset-pasword

import expressAsyncHandler from 'express-async-handler';
import { CustomRequest } from './user.controller';
import Branch from '../models/branch.model';

export const newBranch = expressAsyncHandler(async (req: CustomRequest, res) => {
  const data = req.body;
  try {
    const createBranch = await Branch.create(data);
    res.status(200).json(createBranch);
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

export const updateBranch = expressAsyncHandler(async (req: CustomRequest, res) => {
  const data = req.body;
  try {
    const updateBranch = await Branch.findByIdAndUpdate(req.params.id, data, { new: true });
    res.status(200).json(updateBranch);
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

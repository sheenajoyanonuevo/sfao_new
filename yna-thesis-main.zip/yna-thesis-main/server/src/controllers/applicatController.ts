import expressAsyncHandler from 'express-async-handler';
import { CustomRequest } from './user.controller';
import Applicant from '../models/applicant.model';
import mongoose from 'mongoose';

export const newApplicant = expressAsyncHandler(async (req: CustomRequest, res) => {
  const data = req.body;
  try {
    if (!mongoose.isValidObjectId(data._id)) {
      delete data._id;
      const createApplicant = await Applicant.create(data);
      res.status(200).json(createApplicant);
    } else {
      const updateApplicant = await Applicant.findByIdAndUpdate(data._id, data, { new: true });
      console.log(data)
      res.status(200).json(updateApplicant);
    }
  } catch (error) {
    res.status(500).json({ msg: error.message });
  }
});

export const getApplicant = async (req: CustomRequest, res) => {
  const applicants = await Applicant.find({}).sort({ createdAt: -1 });
  const filterApplicant = applicants.filter((x) => x.schoolYear === req.params.id);
  return res.status(200).json(filterApplicant);
};
